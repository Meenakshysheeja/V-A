Source code for our wedding website 👫 (https://we.shyamjos.com/) , Based on HTML theme https://freehtml5.co/wedding-free-html5-bootstrap-template-for-wedding-websites

To set the countdown date see below section in `js/clock.js`

````
  // Target future date/24 hour time/Timezone
  let targetDate = moment.tz("2023-10-29 12:00", "Asia/Kolkata");
````

## Screenshot
![screenshot](https://repository-images.githubusercontent.com/698651028/d9cbed4d-10e2-44bd-bca8-e26a251ff182)
